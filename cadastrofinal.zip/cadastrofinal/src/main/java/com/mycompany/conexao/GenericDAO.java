package com.mycompany.conexao;

import com.mycompany.classes.Assistido;
import com.mycompany.classes.Usuario;
import com.mycompany.classes.Voluntario;
import com.mycompany.classes.Pns;
import com.mycompany.classes.Morador;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;
 import org.hibernate.Session;

/**
 * Classe responsável por gerenciar o banco de dados
 */
public class GenericDAO<T extends EntidadeBase> {

    private static EntityManager entityManager; //hibernate
    
    public GenericDAO() {
        entityManager = ConnectionFactory.getEntityManager();
        
    }

    public Session getSession() {
        return entityManager.unwrap(Session.class);
    }

    /**
     * Método responsável por Salvar
     *
     */
    public boolean saveOrUpdate(T obj) {
        try {
            entityManager = ConnectionFactory.getEntityManager();
            entityManager.getTransaction().begin();
            if (obj.getId() == null) {
                entityManager.persist(obj);
            } else {
                entityManager.merge(obj);
            }
            entityManager.getTransaction().commit();
            return true;
        } catch (Exception e) {
            entityManager.getTransaction().rollback();
            return false;
        } finally {
            entityManager.close();
        }
    }

    /**
     * Método responsável por retornar um item por ID
     *
     */
    public T findById(Class<T> clazz, Integer id) {
        return entityManager.find(clazz, id);
    }

    public Assistido findAssistidoBycpf(String  cpf){
        Assistido assistido= null;
        
        try{
            Query query= entityManager.createNamedQuery("Find Assistido By cpf");
            query.setParameter("parametro", cpf);
            assistido= (Assistido) query.setMaxResults(1).getSingleResult();           
        } catch (Exception e) {
            assistido= null;
        }finally {
            
        }
        return assistido;
    }
    
    public Voluntario findVoluntarioBycpf(String  cpf){
        Voluntario voluntario= null;
        
        try{
            Query query= entityManager.createNamedQuery("Find Voluntario By cpf");
            query.setParameter("parametro", cpf);
            voluntario= (Voluntario) query.setMaxResults(1).getSingleResult();           
        } catch (Exception e) {
            voluntario= null;
        }finally {
            
        }
        return voluntario;
    }
    
    public Usuario findUsuarioBycpf(String  cpf){
        Usuario usuario= null;
        
        try{
            Query query= entityManager.createNamedQuery("Find Usuario By cpf");
            query.setParameter("parametro", cpf);
            usuario= (Usuario) query.setMaxResults(1).getSingleResult();           
        } catch (Exception e) {
            usuario= null;
        }finally {
            
        }
        return usuario;
    }
    
    public Pns findPnsBycpf(String  cpf){
        Pns pns = null;
        
        try{
            Query query= entityManager.createNamedQuery("Find Pns By cpf");
            query.setParameter("parametro", cpf);
            pns = (Pns) query.setMaxResults(1).getSingleResult();           
        } catch (Exception e) {
            pns = null;
        }finally {
            
        }
        return pns;
    }
    
    public Assistido findAssistidoBynome(String  nome){
        Assistido assistido = null;
        
        try{
            Query query= entityManager.createNamedQuery("Find Assistido By nome");
            query.setParameter("parametro", nome);
            assistido = (Assistido) query.setMaxResults(1).getSingleResult();           
        } catch (Exception e) {
            assistido = null;
        }finally {
            
        }
        return assistido;
    }
    
    /**
     * Método responsável por excluir
     *
     */
    public boolean remove(Class<T> clazz, Integer id) {
        try {
            entityManager = ConnectionFactory.getEntityManager();
            T t = findById(clazz, id);
            entityManager.getTransaction().begin();
            entityManager.remove(t);
            entityManager.getTransaction().commit();
            return true;
        } catch (Exception e) {
            entityManager.getTransaction().rollback();
            return false;
        } finally {
            entityManager.close();
        }
    }

    /**
     * Método responsável por listar os item da entidade
     *
     */
    public List<T> list(Class<T> entidade) {
        entityManager = ConnectionFactory.getEntityManager();
        List<T> lista = null;
        try {

            EntityTransaction transaction = entityManager.getTransaction();
            transaction.begin();

            lista = entityManager.createQuery("from " + entidade.getName()+ " r").getResultList(); 

            transaction.commit();
        } catch (Exception e) {
            entityManager.getTransaction().rollback();
        } finally {

            entityManager.close();
        }

        return lista;
    }
 
}
