/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.classes;

import com.mycompany.conexao.EntidadeBase;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author Nairon Luiz
 */
@Entity
@Table(name = "assistido")
@NamedQueries({
    @NamedQuery(name = "Assistido.findAll", query = "SELECT a FROM Assistido a")})
@NamedQuery(name= "Find Assistido By cpf", query = "SELECT a FROM Assistido a WHERE a.cpf = :parametro")

public class Assistido implements Serializable, EntidadeBase {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "nome")
    private String nome;
    @Basic(optional = false)
    @Column(name = "cpf")
    private String cpf;
    @Basic(optional = false)
    @Column(name = "rg")
    private String rg;
    @Basic(optional = false)
    @Column(name = "datanascimento")
    @Temporal(TemporalType.DATE)
    private Date datanascimento;
    @Column(name = "telefone")
    private String telefone;
    @Column(name = "endere\u00e7o")
    private String endereço;
    @Column(name = "bairro")
    private String bairro;
    @Column(name = "cidade")
    private String cidade;
    @Column(name = "estado")
    private String estado;
    @Column(name = "cep")
    private String cep;
    @Column(name = "estadocivil")
    private String estadocivil;
    @Column(name = "escolaridade")
    private String escolaridade;
    @Column(name = "bolsafamilia")
    private String bolsafamilia;
    @Column(name = "rendacidada")
    private String rendacidada;
    @Column(name = "cadunico")
    private String cadunico;
    @Column(name = "doen\u00e7asconhecidas")
    private String doençasconhecidas;
    @Column(name = "trabalha")
    private String trabalha;
    @Column(name = "aposentado")
    private String aposentado;
    @Column(name = "recebepensao")
    private String recebepensao;
    @Lob
    @Column(name = "observa\u00e7\u00e3opensao")
    private String observaçãopensao;
    @Column(name = "numeromoradores")
    private String numeromoradores;
    @Lob
    @Column(name = "observa\u00e7\u00e3o")
    private String observação;

    public Assistido() {
    }

    public Assistido(Integer id) {
        this.id = id;
    }

    public Assistido(Integer id, String nome, String cpf, String rg, Date datanascimento) {
        this.id = id;
        this.nome = nome;
        this.cpf = cpf;
        this.rg = rg;
        this.datanascimento = datanascimento;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getRg() {
        return rg;
    }

    public void setRg(String rg) {
        this.rg = rg;
    }

    public Date getDatanascimento() {
        return datanascimento;
    }

    public void setDatanascimento(Date datanascimento) {
        this.datanascimento = datanascimento;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getEndereço() {
        return endereço;
    }

    public void setEndereço(String endereço) {
        this.endereço = endereço;
    }

    public String getBairro() {
        return bairro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getCep() {
        return cep;
    }

    public void setCep(String cep) {
        this.cep = cep;
    }

    public String getEstadocivil() {
        return estadocivil;
    }

    public void setEstadocivil(String estadocivil) {
        this.estadocivil = estadocivil;
    }

    public String getEscolaridade() {
        return escolaridade;
    }

    public void setEscolaridade(String escolaridade) {
        this.escolaridade = escolaridade;
    }

    public String getBolsafamilia() {
        return bolsafamilia;
    }

    public void setBolsafamilia(String bolsafamilia) {
        this.bolsafamilia = bolsafamilia;
    }

    public String getRendacidada() {
        return rendacidada;
    }

    public void setRendacidada(String rendacidada) {
        this.rendacidada = rendacidada;
    }

    public String getCadunico() {
        return cadunico;
    }

    public void setCadunico(String cadunico) {
        this.cadunico = cadunico;
    }

    public String getDoençasconhecidas() {
        return doençasconhecidas;
    }

    public void setDoençasconhecidas(String doençasconhecidas) {
        this.doençasconhecidas = doençasconhecidas;
    }

    public String getTrabalha() {
        return trabalha;
    }

    public void setTrabalha(String trabalha) {
        this.trabalha = trabalha;
    }

    public String getAposentado() {
        return aposentado;
    }

    public void setAposentado(String aposentado) {
        this.aposentado = aposentado;
    }

    public String getRecebepensao() {
        return recebepensao;
    }

    public void setRecebepensao(String recebepensao) {
        this.recebepensao = recebepensao;
    }

    public String getObservaçãopensao() {
        return observaçãopensao;
    }

    public void setObservaçãopensao(String observaçãopensao) {
        this.observaçãopensao = observaçãopensao;
    }

    public String getNumeromoradores() {
        return numeromoradores;
    }

    public void setNumeromoradores(String numeromoradores) {
        this.numeromoradores = numeromoradores;
    }

    public String getObservação() {
        return observação;
    }

    public void setObservação(String observação) {
        this.observação = observação;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Assistido)) {
            return false;
        }
        Assistido other = (Assistido) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.mycompany.classes.Assistido[ id=" + id + " ]";
    }
    
}
