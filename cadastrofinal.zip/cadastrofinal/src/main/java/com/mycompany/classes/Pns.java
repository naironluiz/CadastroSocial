/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.classes;

import com.mycompany.conexao.EntidadeBase;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author Nairon Luiz
 */
@Entity
@Table(name = "pns")
@NamedQueries({
    @NamedQuery(name = "Pns.findAll", query = "SELECT p FROM Pns p")})
@NamedQuery(name= "Find Pns By cpf", query = "SELECT p FROM Pns p WHERE p.cpf = :parametro")
public class Pns implements Serializable, EntidadeBase {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "nome")
    private String nome;
    @Basic(optional = false)
    @Column(name = "cpf")
    private String cpf;
    @Basic(optional = false)
    @Column(name = "rg")
    private String rg;
    @Basic(optional = false)
    @Column(name = "datanascimento")
    @Temporal(TemporalType.DATE)
    private Date datanascimento;
    @Column(name = "telefone")
    private String telefone;
    @Column(name = "endere\u00e7o")
    private String endereço;
    @Column(name = "bairro")
    private String bairro;
    @Column(name = "cidade")
    private String cidade;
    @Column(name = "estado")
    private String estado;
    @Column(name = "cep")
    private String cep;
    @Basic(optional = false)
    @Column(name = "varacriminal")
    private String varacriminal;
    @Column(name = "cadastrarvara")
    private String cadastrarvara;
    @Column(name = "datainicio")
    @Temporal(TemporalType.DATE)
    private Date datainicio;
    @Column(name = "datatermino")
    @Temporal(TemporalType.DATE)
    private Date datatermino;
    @Column(name = "mediatotal")
    @Temporal(TemporalType.TIME)
    private Date mediatotal;
    @Column(name = "mediacumprida")
    @Temporal(TemporalType.TIME)
    private Date mediacumprida;
    @Column(name = "diassemana")
    private String diassemana;
    @Column(name = "horassemana")
    @Temporal(TemporalType.TIME)
    private Date horassemana;
    @Lob
    @Column(name = "observa\u00e7\u00e3o")
    private String observação;

    public Pns() {
    }

    public Pns(Integer id) {
        this.id = id;
    }

    public Pns(Integer id, String nome, String cpf, String rg, Date datanascimento, String varacriminal) {
        this.id = id;
        this.nome = nome;
        this.cpf = cpf;
        this.rg = rg;
        this.datanascimento = datanascimento;
        this.varacriminal = varacriminal;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getRg() {
        return rg;
    }

    public void setRg(String rg) {
        this.rg = rg;
    }

    public Date getDatanascimento() {
        return datanascimento;
    }

    public void setDatanascimento(Date datanascimento) {
        this.datanascimento = datanascimento;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getEndereço() {
        return endereço;
    }

    public void setEndereço(String endereço) {
        this.endereço = endereço;
    }

    public String getBairro() {
        return bairro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getCep() {
        return cep;
    }

    public void setCep(String cep) {
        this.cep = cep;
    }

    public String getVaracriminal() {
        return varacriminal;
    }

    public void setVaracriminal(String varacriminal) {
        this.varacriminal = varacriminal;
    }

    public String getCadastrarvara() {
        return cadastrarvara;
    }

    public void setCadastrarvara(String cadastrarvara) {
        this.cadastrarvara = cadastrarvara;
    }

    public Date getDatainicio() {
        return datainicio;
    }

    public void setDatainicio(Date datainicio) {
        this.datainicio = datainicio;
    }

    public Date getDatatermino() {
        return datatermino;
    }

    public void setDatatermino(Date datatermino) {
        this.datatermino = datatermino;
    }

    public Date getMediatotal() {
        return mediatotal;
    }

    public void setMediatotal(Date mediatotal) {
        this.mediatotal = mediatotal;
    }

    public Date getMediacumprida() {
        return mediacumprida;
    }

    public void setMediacumprida(Date mediacumprida) {
        this.mediacumprida = mediacumprida;
    }

    public String getDiassemana() {
        return diassemana;
    }

    public void setDiassemana(String diassemana) {
        this.diassemana = diassemana;
    }

    public Date getHorassemana() {
        return horassemana;
    }

    public void setHorassemana(Date horassemana) {
        this.horassemana = horassemana;
    }

    public String getObservação() {
        return observação;
    }

    public void setObservação(String observação) {
        this.observação = observação;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Pns)) {
            return false;
        }
        Pns other = (Pns) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.mycompany.classes.Pns[ id=" + id + " ]";
    }
    
}
