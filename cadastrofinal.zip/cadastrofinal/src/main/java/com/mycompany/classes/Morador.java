/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.classes;

import com.mycompany.conexao.EntidadeBase;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author Nairon Luiz
 */
@Entity
@Table(name = "morador")
@NamedQueries({
    @NamedQuery(name = "Morador.findAll", query = "SELECT m FROM Morador m")})
public class Morador implements Serializable, EntidadeBase {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "nome")
    private String nome;
    @Basic(optional = false)
    @Column(name = "datanascimento")
    @Temporal(TemporalType.DATE)
    private Date datanascimento;
    @Column(name = "telefone")
    private String telefone;
    @Basic(optional = false)
    @Column(name = "parentesco")
    private String parentesco;
    @Column(name = "frequenta")
    private String frequenta;
    @Column(name = "escolaridade")
    private String escolaridade;
    @Column(name = "estudando")
    private String estudando;
    @Lob
    @Column(name = "observa\u00e7\u00e3o")
    private String observação;
    @JoinColumn(name = "assistido_id", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private Assistido assistidoId;

    public Morador() {
    }

    public Morador(Integer id) {
        this.id = id;
    }

    public Morador(Integer id, String nome, Date datanascimento, String parentesco) {
        this.id = id;
        this.nome = nome;
        this.datanascimento = datanascimento;
        this.parentesco = parentesco;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Date getDatanascimento() {
        return datanascimento;
    }

    public void setDatanascimento(Date datanascimento) {
        this.datanascimento = datanascimento;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getParentesco() {
        return parentesco;
    }

    public void setParentesco(String parentesco) {
        this.parentesco = parentesco;
    }

    public String getFrequenta() {
        return frequenta;
    }

    public void setFrequenta(String frequenta) {
        this.frequenta = frequenta;
    }

    public String getEscolaridade() {
        return escolaridade;
    }

    public void setEscolaridade(String escolaridade) {
        this.escolaridade = escolaridade;
    }

    public String getEstudando() {
        return estudando;
    }

    public void setEstudando(String estudando) {
        this.estudando = estudando;
    }

    public String getObservação() {
        return observação;
    }

    public void setObservação(String observação) {
        this.observação = observação;
    }

    public Assistido getAssistidoId() {
        return assistidoId;
    }

    public void setAssistidoId(Assistido assistidoId) {
        this.assistidoId = assistidoId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Morador)) {
            return false;
        }
        Morador other = (Morador) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.mycompany.classes.Morador[ id=" + id + " ]";
    }
    
}
